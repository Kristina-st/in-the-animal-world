#include<iostream>
#include<string>
#include"Function.h"


Animal& Animal::operator= (const Animal& A) {
    this->health = A.health;
    this->name = A.name;
    return *this;
}

Carnivore& Carnivore::operator= (const Carnivore& A) {
    this->force = A.force;
    return *this;
}

Herbivore& Herbivore::operator= (const Herbivore& A) {
    this->luckiness = A.luckiness;
    return *this;
}

rezult Wolf::Interact(Animal& other) {

    if (typeid(other) == typeid(Wolf)) return love;
    if (typeid(other) == typeid(Fox)) return friends;
    if (typeid(other) == typeid(Hare)) return kill;
    if (typeid(other) == typeid(Elk)) return kill;

};

rezult Fox::Interact(Animal& other) {

    if (typeid(other) == typeid(Fox)) return love;
    if (typeid(other) == typeid(Wolf)) return friends;
    if (typeid(other) == typeid(Hare)) return kill;
    if (typeid(other) == typeid(Elk)) return kill;

};

rezult Elk::Interact(Animal& other) {

    if (typeid(other) == typeid(Fox)) return eat;
    if (typeid(other) == typeid(Wolf)) return eat;
    if (typeid(other) == typeid(Hare)) return friends;
    if (typeid(other) == typeid(Elk)) return love;

};


rezult Hare::Interact(Animal& other) {

    if (typeid(other) == typeid(Fox)) return eat;
    if (typeid(other) == typeid(Wolf)) return eat;
    if (typeid(other) == typeid(Hare)) return love;
    if (typeid(other) == typeid(Elk)) return friends;

};