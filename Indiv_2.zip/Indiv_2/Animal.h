#pragma once
#include<iostream>
#include<string>
#include<ctime>

using namespace std;

enum rezult {
    love,
    friends,
   	eat,
    kill
};

class Animal {
public:
    string name;
    double health;
public:
    Animal(string name) : name(name), health(1) {};
    virtual rezult Interact(Animal& other) = 0;

    Animal& operator=(const Animal& A);
};

class Carnivore : public Animal {
protected:
    double force; // ����
public:
    Carnivore(string name) : Animal(name) {
        srand(time(0));
        force = (1 + rand() % 5) / 10.0;
    };

    double get_force() { return force; }

    Carnivore& operator=(const Carnivore& A);
};

class Elk;
class Hare;
class Fox;
class Wolf;

class Wolf : public Carnivore {
public:
    Wolf(string name) : Carnivore(name) { force += 0.1; };

    rezult Interact(Animal& other);

    std::string get_name() { return name; }
    double get_force() { return force; }
    double get_health() { return health; }

};

class Fox : public Carnivore {
public:
    Fox(string name) : Carnivore(name) {  };

     rezult Interact(Animal& other);

     std::string get_name() { return name; }
     double get_force() { return force; }
     double get_health() { return health; }
};


class Herbivore: public Animal {
protected:
	double luckiness; // �����������
public:
	Herbivore(std::string name) : Animal(name) { 
		srand(time(0));
		luckiness = (rand() % 15) / 10.0;
	};

    double get_luckiness();

    Herbivore& operator=(const Herbivore& A);
};

class Hare : public Herbivore {
public:
    Hare(string name) : Herbivore(name) {  };

    rezult Interact(Animal& other);
	
    std::string get_name() { return name; }
    double get_luckiness()  { return luckiness; }
    double get_health() { return health; }
};

class Elk : public Herbivore {
public:
    Elk(string name) : Herbivore(name) { luckiness += 0.5; };

    rezult Interact(Animal& other);

    std::string get_name() { return name; }
    double get_luckiness() { return luckiness; }
    double get_health() { return health; }
};