#pragma once
#include"Animal.h"

void dell(Animal**& a, int&  n);

void print(Animal** a, int n);
