#include<iostream>
using namespace std;
#include"Animal.h"

void dell(Animal**& a, int&  n) {
	int k = 0;
	Animal** new_arr = new Animal *[n - 1];
	bool flag;

	for (int i = 0; i < n; i++) {
		flag = true;

		if (a[i]->health == 0) flag = false;

		if (flag == true) {
			new_arr[k] = a[i];
			k++;
		}
	}

	n = n - 1;

	delete[] a;
	a = new_arr;
}

void print(Animal **a, int n) {

	for (int i = 0; i < n; i++) {

		if (typeid(*a[i]) == typeid(Fox))  cout << "Fox: " << a[i]->name << " " << a[i]->health << " ����: " << dynamic_cast<Fox*>(a[i])->get_force() << endl;
		if (typeid(*a[i]) == typeid(Elk))  cout << "Elk: " << a[i]->name << " " << a[i]->health << " ����� : " << dynamic_cast<Elk*>(a[i])->get_luckiness() << endl;
		if (typeid(*a[i]) == typeid(Hare))  cout << "Hare: " << a[i]->name << " " << a[i]->health << " �����: " << dynamic_cast<Hare*>(a[i])->get_luckiness() << endl;
		if (typeid(*a[i]) == typeid(Wolf))  cout << "Wolf: " << a[i]->name << " " << a[i]->health << " ����: " << dynamic_cast<Wolf*>(a[i])->get_force() << endl;
	}
}